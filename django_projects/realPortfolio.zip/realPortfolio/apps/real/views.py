# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse


def index(request):
    print "on the landing page"
    return render(request, 'real/index.html')

def one(request):
    'print moving to first page'
    return render(request, 'real/first.html')

def two(request):
    'print moving to second page'
    return render(request, 'real/second.html')

def three(request):
    'print on the third page'
    return render(request, 'real/third.html')

# Create your views here.
