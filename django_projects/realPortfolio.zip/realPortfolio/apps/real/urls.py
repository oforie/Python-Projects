from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^first$', views.one),
    url(r'^second$', views.two),
    url(r'^third', views.three)
]