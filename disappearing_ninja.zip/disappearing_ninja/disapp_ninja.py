#pylint: disable = c0111, c0103

from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    print "It's working yo!"
    return render_template('disapp_ninja.html')

@app.route('/ninja')
def all_ninja():
    return render_template('ninjas.html')

@app.route('/ninja/<ninja_color>')
def color(ninja_color):
    print '***', ninja_color
    return render_template('ninja_color.html', ninja_color=ninja_color)

app.run(debug=True)
