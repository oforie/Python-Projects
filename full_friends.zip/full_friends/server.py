from flask import Flask, render_template, request, redirect, session, flash
from mysqlconnection import MySQLConnector
app=Flask(__name__)
mysql = MySQLConnector(app,'full_friends')

@app.route('/')
def index():
    print "---starting now----"
    query = "SELECT * FROM friends"
    friends = mysql.query_db(query)
    print friends
    return render_template('index.html', my_friends=friends)

@app.route('/process', methods=['POST'])
def newFriends():
    print request.form
    print request.form['first_name']
    print request.form['last_name']
    query = "INSERT INTO friends (first_name, last_name) VALUES (:first_name, :last_name)"
  
    data = {
             'first_name': request.form['first_name'],
             'last_name':  request.form['last_name']
           }
    mysql.query_db(query, data)
    return redirect('/')

app.run(debug=True)