from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
app.secret_key = 'ThisIsSecret'

def win_lose(choice): 
    import random

   
    computer_input=random.randint(0,2) 
    print computer_input

    if choice == 'rock':
       user_value = 0

    if choice == 'paper':
       user_value = 1

    if choice == 'scissors':
       user_value = 2

    print user_value
    if user_value == computer_input:
        session['tie'] = session['tie'] + 1

    elif user_value > computer_input:
        session['win'] = session['win'] + 1
       
    else:
        session['lose'] = session['lose'] + 1

    return redirect('/result')




@app.route('/')
def index():
    print "Hello I'm ready"
    if 'tie' in session:
        print 'tie'

    else: 
        session['tie']=0

    if 'win' in session:
        print 'win'

    else: 
        session['win']=0

    if 'lose' in session:
        print 'lose'
    else: 
        session['lose']=0

    return render_template('rps.html')

@app.route('/result', methods=['POST'])
def game():
    print request.form

    choice=request.form['choice']
    win_lose(choice)
    print choice

    return render_template('result.html', win=session['win'], lose=session['lose'], tie=session['tie'])



app.run(debug=True)