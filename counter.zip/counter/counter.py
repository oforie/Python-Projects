from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)

app.secret_key = 'ThisIsSecret'


@app.route('/')
def number():
    print 'We are live!'
    try:
        session['number'] += 1
    except:
        session['number'] = 1
    return render_template('counter.html')

@app.route('/increase2', methods=['POST'])
def increase2():
    print 'adding two'
    session['number'] += 2
    return redirect('/')

@app.route('/reset', methods=['POST'])
def reset():
    print 'back to zero'
    session['number']= 0
    return redirect('/')

app.run(debug=True)

