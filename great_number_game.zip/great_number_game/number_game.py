from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
app.secret_key = 'ThisIsSecret'


import random
comp = int(random.randint(1,101))

@app.route('/')
def index():
    print "Starting in 1..2..3"
    session['pc_num'] = comp
    print '---Computer generated #', session['pc_num']
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def play():
    print request.form
    print request.form['player']
    session['player_guess']=request.form['player']   
    print "--player entered....", session['player_guess']
    print "--the computer generated", session['pc_num']

    if session['pc_num'] == session['player_guess']
        print "You Won!"
        print "Play again!"
    elif session['pc_num'] > session['player_guess']

    elif session['pc_num'] < session['player_guess'] 
        print 'Too high'
        print 'Too low!'
    else: 
        print "Let's play" 
  

    return redirect('/')
    session.pop('player_guess')
    session.pop('pc_num')

app.run(debug=True)
